export const MenuList = [
    //Dashboard
    {
        title: 'Dashboard',	
        classsChange: 'mm-collapse',		
        iconStyle: <i className="flaticon-025-dashboard"></i>,
        content: [
            {
                title: 'Dashboard Light',
                to: 'dashboard',					
            },
            {
                title: 'Dashboard Dark',
                to: 'dashboard-dark',
            },
        ],
    },
    //Users
    {
        title: "User",
        classsChange: "mm-collapse",
        //update:"New",
        iconStyle: <i class="fas fa-user"></i>,
    
        content: [
          {
            title: "User List",
            to: "/user",
          },
          {
            title: "User Inactive List",
            to: "/user-list",
          },
          {
            title: "User Add",
            to: "/user-add",
          },
        {
            title: "User Edit",
            to: "/user-edit",
          },
        ],
      },
     
     //Location Management
     {
        title : "Location",
        classsChange: 'mm-collapse',
        //update:"New",
        iconStyle: 
        <i class="fas fa-map-marker-alt"></i>,        
        content:[
            {
                title:'Location',
                to:'/location'
            },
            {
                title:'Inactive Location',
                to:'/location-inactive'
            },
            {
                title:'Add Location',
                to:'/location-add'
            },
            
        ],
    },

    //Master List

    {
        title : "Master List",
        classsChange: 'mm-collapse',
        //update:"New",
        iconStyle: 
            <i className="fa-solid fa fa-cog fw-bold" />,        
        content:[
            {
                title:'Master List',
                to:'/master-list'
            },
            {
                title:'Master Add',
                to:'/master-add'
            },
            {
                title:'Master Bulk',
                to:'/master-bulk'
            },
            {
                title:'Master Category',
                to:'/master-cat'
            },
            {
                title:'Master Unit',
                to:'/master-unit'
            },

            
        ],
    },
    
    
    
    
    //Charts
    {
        title: 'Charts',	
        classsChange: 'mm-collapse',
        iconStyle: <i className="flaticon-041-graph"></i>,
        content: [
            
            {
                title: 'RechartJs',
                to: 'chart-rechart',					
            },
            {
                title: 'Chartjs',
                to: 'chart-chartjs',					
            },
            {
                title: 'Sparkline',
                to: 'chart-sparkline',					
            },
            {
                title: 'Apexchart',
                to: 'chart-apexchart',					
            },
        ]
    },
 
    //Pages
    {
        title:'Pages',
        classsChange: 'mm-collapse',
        iconStyle: <i className="flaticon-022-copy"></i>,
        content : [
            {
                title:'Error',
                hasMenu : true,
                content : [
                    {
                        title: 'Error 400',
                        to : 'page-error-400',
                    },
                    {
                        title: 'Error 403',
                        to : 'page-error-403',
                    },
                    {
                        title: 'Error 404',
                        to : 'page-error-404',
                    },
                    {
                        title: 'Error 500',
                        to : 'page-error-500',
                    },
                    {
                        title: 'Error 503',
                        to : 'page-error-503',
                    },
                ],
            },
            {
                title:'Lock Screen',
                to: 'page-lock-screen',
            },

        ]
    },
    
]