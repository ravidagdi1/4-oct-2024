import React, { useEffect, useState, useRef } from "react";
import PageTitle from "../../layouts/PageTitle";
import { Link } from "react-router-dom";
import { Tab, Nav } from "react-bootstrap";
import Collapse from "react-bootstrap/Collapse";
import UserAdd from "../User/UserAdd";
import useAsync from "../../../hooks/useAsync";
import UserServices from "../../../services/UserServices";
import UserPending from "./UserPending";
import Swal from "sweetalert2";
import Select from 'react-select';


const User = () => {
  const [open, setOpen] = useState(true);
  const [open2, setOpen2] = useState(true);
  const [sort,setsort]=useState(5)// Number of items per page
  const activePag = useRef(0);
  const [test, setTest] = useState(0);
  const { data, error, isLoading, run } = useAsync(UserServices.getAllUser);

  const options = [
    //{ value: '1', label: 'Select Status' },
    { value: '5', label: '5' },
    { value: '10', label: '10' },
    { value: '20', label: '20' },
    { value: '50', label: '50' },
    { value: '100', label: '100' }
  ]

  // Function to change the displayed data based on pagination
  const changeData = (first, second) => {
    const domData = Array.from(
      document.querySelectorAll("#transactions-data tbody tr")
    );
    domData.forEach((row, index) => {
      if (index >= first && index < second) {
        row.classList.remove("d-none");
      } else {
        row.classList.add("d-none");
      }
    });
  };

  // Pagination setup
  useEffect(() => {
    if (data?.data?.data?.length > 0) {
      changeData(activePag.current * sort, (activePag.current + 1) * sort);
    }
  }, [data?.data?.data]);

  // Correct the pagination calculation
  const pagination = Math.ceil((data?.data?.data?.length || 0) / sort);

  const onClick = (i) => {
    activePag.current = i;
    changeData(activePag.current * sort, (activePag.current + 1) * sort);
    setTest(i);
  };
  //delete function
  function handleDelete(e) {
    Swal.fire({
      title: 'Are you sure to delete ?',
      text: "You will not be able to recover this User Again !!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dd6b55',
      cancelButtonColor: '#aaa',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire(
          'Deleted!',
          'User has been deleted.',
          'success'
        )
      }
    })


  }
  return (
    <>

      <div className="row">
        <div className="col-xl-12">
          <div className="filter cm-content-box box-primary">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fas fa-filter me-2"></i>Filter
              </div>
              <div className="tools">
                <Link to={"#"} className={`SlideToolHeader ${open ? 'collapse' : 'expand'}`}
                  onClick={() => setOpen(!open)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="row">
                    <div className="col-xl-3 col-xxl-6">
                      <input type="text" className="form-control mb-xl-0 mb-3" id="exampleFormControlInput1" placeholder="Search" />
                    </div>
                    <div className="col-xl-3 col-xxl-6">
                      <Select
                      placeholder="Select row to display in User Table"
                        value={options.find(option => option.value === sort)} // set the current selected value
                        onChange={(selectedOption) => setsort(selectedOption.value)} // update `sort` on selection
                        isSearchable={false}
                        options={options}
                        className="custom-react-select mb-3 mb-xxl-0"
                      />
                    </div>

                    
                  </div>

                </div>
              </div>
            </Collapse>
          </div>
          <div className="filter cm-content-box box-primary mt-5">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fas fa-file-word me-2"></i>Active User
                List
              </div>
              <div className="tools">
                <Link
                  to={"#"}
                  className={`SlideToolHeader ${open2 ? "collapse" : "expand"
                    }`}
                  onClick={() => setOpen2(!open2)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>

            <Collapse in={open2}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="table-responsive">
                    <div
                      id="content_wrapper"
                      className="dataTables_wrapper no-footer"
                    >
                      <table
                        className="table table-bordered table-responsive-lg table-striped table-condensed flip-content"
                        id="transactions-data"
                      >
                        <thead>
                          <tr>
                            <th>S.No</th>
                            <th>User Role</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Store</th>
                            <th>Status</th>
                            <th className="text-end">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {Array.isArray(data?.data?.data) && data?.data?.data?.length > 0 ? (
                            data?.data?.data
                              .slice(activePag.current * sort, (activePag.current + 1) * sort)
                              .map((item, index) => (
                                <tr key={index}>
                                  <td>{activePag.current * sort + index + 1}</td>
                                  <td>{item?.role}</td>
                                  <td>{item?.name}</td>
                                  <td>{item?.email}</td>
                                  <td>{item?.store[0]?.name}</td>
                                  <td>{item?.status}</td>
                                  <td className="text-end">
                                    <Link to={"/add-content"} className="btn btn-warning btn-sm content-icon me-1">
                                      <i className="fa fa-edit"></i>
                                    </Link>
                                    <button className="btn btn-danger btn-sm content-icon ms-1" onClick={(e) => { handleDelete(e) }}>
                                      <i className="fa fa-times"></i>
                                    </button>
                                  </td>
                                </tr>
                              ))
                          ) : (
                            <tr>
                              <td colSpan="7">No data available</td>
                            </tr>
                          )}
                        </tbody>

                      </table>
                      <div className="d-sm-flex text-center justify-content-between align-items-center mt-3">
                        <div className="dataTables_info">
                          Showing {activePag.current * sort + 1} to{" "}
                          {Math.min(
                            data?.data?.data?.length,
                            (activePag.current + 1) * sort
                          )}{" "}
                          of {data?.data?.data?.length} entries
                        </div>
                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link
                            className="paginate_button previous"
                            to="#"
                            onClick={() =>
                              activePag.current > 0 &&
                              onClick(activePag.current - 1)
                            }
                          >
                            <i
                              className="fa fa-angle-double-left"
                              aria-hidden="true"
                            ></i>
                          </Link>
                          <span>
                            {Array.from(
                              { length: pagination },
                              (_, i) => (
                                <Link
                                  key={i}
                                  to="#"
                                  className={`paginate_button ${activePag.current === i
                                    ? "current"
                                    : ""
                                    }`}
                                  onClick={() => onClick(i)}
                                >
                                  {i + 1}
                                </Link>
                              )
                            )}
                          </span>
                          <Link
                            className="paginate_button next"
                            to="#"
                            onClick={() =>
                              activePag.current + 1 < pagination &&
                              onClick(activePag.current + 1)
                            }
                          >
                            <i
                              className="fa fa-angle-double-right"
                              aria-hidden="true"
                            ></i>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
        </div>
      </div>
    </>
  );
};

export default User;
