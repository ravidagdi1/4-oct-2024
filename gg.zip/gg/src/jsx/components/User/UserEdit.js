import React from "react";
import { Modal, Button, Form } from "react-bootstrap";

const UserEdit = ({ show, onHide, user }) => {
  console.log("user", user);
  return (
    <Modal show={show} onHide={onHide}>
      <Modal.Header closeButton>
        <Modal.Title>Edit User</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group className="mb-3">
            <Form.Label>Role</Form.Label>
            <Form.Control
              type="text"
              defaultValue={user?.role}
              placeholder="Enter Role"
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>Store</Form.Label>
            <Form.Control
              type="text"
              defaultValue={user?.store[0]?.name}
              placeholder="Enter Store"
            />
          </Form.Group>
          {/* Add more fields as necessary */}
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
        <Button variant="primary">Save Changes</Button>
      </Modal.Footer>
    </Modal>
      );
    };
    
    export default UserEdit;
