import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import { Tab, Nav } from "react-bootstrap";
import axios from "axios";
import MasterListBulk from "../MasterList/MasterListBulk";
import MasterListAdd from "../MasterList/MasterListAdd";
import MasterCat from "../MasterList/MasterCat";
import MasterUnit from "../MasterList/MasterUnit";
import Collapse from "react-bootstrap/Collapse";
import Select from 'react-select';
import ProductServices from "../../../services/ProductServices";

const MasterList = () => {
  const [open, setOpen] = useState(true);
  const [open2, setOpen2] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [data, setData] = useState([]);
  const [sort, setsort] = useState(5) // Number of items per page
  const activePag = useRef(0);
  const [test, setTest] = useState(0);

  //Display row 
  const options = [
    //{ value: '1', label: 'Select Status' },
    { value: '5', label: '5' },
    { value: '10', label: '10' },
    { value: '20', label: '20' },
    { value: '50', label: '50' },
    { value: '100', label: '100' }
  ]

  // Function to change the displayed data based on pagination
  const changeData = (first, second) => {
    const domData = Array.from(
      document.querySelectorAll("#transactions-data tbody tr")
    );
    domData.forEach((row, index) => {
      if (index >= first && index < second) {
        row.classList.remove("d-none");
      } else {
        row.classList.add("d-none");
      }
    });
  };

  // Fetch data from API
  useEffect(() => {

      setLoading(true);
      try {
        ProductServices.getAllProduct().then((response)=>{
          console.log(response)
          setData(response?.data?.data || []); // Set the API data or an empty array
        }).catch((error)=>{
          alert('There is some problem in fatching data !')
        })
        
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
   
  }, []);

  // Pagination setup
  useEffect(() => {
    if (data.length > 0) {
      changeData(activePag.current * sort, (activePag.current + 1) * sort);
    }
  }, [data]);

  const pagination = Math.ceil(data.length / sort); // Calculate number of pages

  const onClick = (i) => {
    activePag.current = i;
    changeData(activePag.current * sort, (activePag.current + 1) * sort);
    setTest(i);
  };

  return (
    <>



      <div className="row">
        <div className="col-xl-12">
          <div className="filter cm-content-box box-primary">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fas fa-filter me-2"></i>Filter
              </div>
              <div className="tools">
                <Link to={"#"} className={`SlideToolHeader ${open ? 'collapse' : 'expand'}`}
                  onClick={() => setOpen(!open)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="row">
                    <div className="col-xl-3 col-xxl-6">
                      <input type="text" className="form-control mb-xl-0 mb-3" id="exampleFormControlInput1" placeholder="Title" />
                    </div>

                    <div className="col-xl-3 col-xxl-6">
                      <Select
                        placeholder="Select row to display in User Table"
                        value={options.find(option => option.value === sort)} // set the current selected value
                        onChange={(selectedOption) => setsort(selectedOption.value)} // update `sort` on selection
                        isSearchable={false}
                        options={options}
                        className="custom-react-select mb-3 mb-xxl-0"
                      />
                    </div>
                   
                  </div>

                </div>
              </div>
            </Collapse>
          </div>
          <div className="filter cm-content-box box-primary mt-5">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fas fa-file-word me-2"></i>Master List
              </div>
              <div className="tools">
                <Link
                  to={"#"}
                  className={`SlideToolHeader ${open2 ? "collapse" : "expand"
                    }`}
                  onClick={() => setOpen2(!open2)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open2}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="table-responsive">
                    <div
                      id="content_wrapper"
                      className="dataTables_wrapper no-footer"
                    >
                      <table
                        className="table table-bordered table-responsive-lg table-striped table-condensed flip-content"
                        id="transactions-data"
                      >
                        <thead>
                          <tr>
                            <th>S.No</th>
                            <th>Part No.</th>
                            <th>Image</th>
                            <th>Category</th>
                            <th>Unit</th>
                            <th>Description</th>
                            <th>Remak</th>
                            <th className="text-end">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {Array.isArray(data) && data.length > 0 ? (
                            data.map((item, index) => (
                              <tr key={index}>
                                <td>
                                  {activePag.current * sort +
                                    index +
                                    1}
                                </td>
                                {/* Corrected S.No */}
                                <td>{item?.partNo}</td>
                                <td></td>
                                <td>{item?.category}</td>
                                <td>{item?.description}</td>
                                <td>{item?.unit}</td>
                                <td>{item?.remark}</td>
                                <td className="text-end">
                                  <Link
                                    to={"/add-content"}
                                    className="btn btn-warning btn-sm content-icon me-1"
                                  >
                                    <i className="fa fa-edit"></i>
                                  </Link>
                                  <Link
                                    to={"#"}
                                    className="btn btn-danger btn-sm content-icon ms-1"
                                  >
                                    <i className="fa fa-times"></i>
                                  </Link>
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan="5">No data available</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                      <div className="d-sm-flex text-center justify-content-between align-items-center mt-3">
                        <div className="dataTables_info">
                          Showing {activePag.current * sort + 1} to{" "}
                          {Math.min(
                            data.length,
                            (activePag.current + 1) * sort
                          )}{" "}
                          of {data.length} entries
                        </div>
                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link
                            className="paginate_button previous"
                            to="/user"
                            onClick={() =>
                              activePag.current > 0 &&
                              onClick(activePag.current - 1)
                            }
                          >
                            <i
                              className="fa fa-angle-double-left"
                              aria-hidden="true"
                            ></i>
                          </Link>
                          <span>
                            {Array.from(
                              { length: pagination },
                              (_, i) => (
                                <Link
                                  key={i}
                                  to="/user"
                                  className={`paginate_button ${activePag.current === i
                                      ? "current"
                                      : ""
                                    }`}
                                  onClick={() => onClick(i)}
                                >
                                  {i + 1}
                                </Link>
                              )
                            )}
                          </span>
                          <Link
                            className="paginate_button next"
                            to="/user"
                            onClick={() =>
                              activePag.current + 1 < pagination &&
                              onClick(activePag.current + 1)
                            }
                          >
                            <i
                              className="fa fa-angle-double-right"
                              aria-hidden="true"
                            ></i>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
        </div>
      </div>

    </>
  );
};

export default MasterList;
