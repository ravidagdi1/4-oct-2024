import PageTItle from "../../layouts/PageTitle";
const MasterListBulk = () => {
  return (
    <>
      <PageTItle activeMenu="Master List Bulk Upload" motherMenu="Master List" pageContent="User" />
      <div className="col-xl-12 col-lg-12">
        <div className="card">
          <div className="card-body">
            <div className="basic-form">
              <form onSubmit={(e) => e.preventDefault()}>
                <div className="row">
                <div className="col-xl-6 col-lg-6">
                <div className="input-group">
               
                <div className="form-file">
                  <input type="file" className="form-file-input form-control" />
                 
                </div>
                <button className="btn btn-primary btn-sm" type="button">
                    Upload
                  </button>
              </div>
              </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default MasterListBulk;
