import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import LocationServices from '../../../services/LocationServices';
import PageTItle from "../../layouts/PageTitle";
import Collapse from "react-bootstrap/Collapse";
import Swal from "sweetalert2";


const LoactionAdd = ({ onSuccess }) => {
  const [open, setOpen] = useState(true);
  const [open2, setOpen2] = useState(true);
  const [formValues, setFormValues] = useState({
    name: '',
    location: '',
  });

  // Handle form input changes
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
  };

  // Handle form submission
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await LocationServices.addStore({
        name: formValues.name,
        location: formValues.location,
      });
      Swal.fire({
        icon: 'success',
        title: 'Good job!',
        text: "Location Added Successfully!",                        
      })
      //alert('Location Added Successfully');
      setFormValues({
        name: '',
        location: '',
      });
      if (onSuccess) {
        onSuccess(); // Call the onSuccess callback to refresh the data
      }
    } catch (error) {
      console.error('Failed to add Location', error);
      alert('Failed to add Location');
    }
  };

  return (
    <>
       <div className="row">
                  <div className="col-xl-12">
                    <div className="filter cm-content-box box-primary mt-5">
                      <div className={`content-title`}>
                        <div className="cpa">
                          <i className="fas fa-file-word me-2"></i>User Add
                        </div>
                        <div className="tools">
                          <Link
                            to={"#"}
                            className={`SlideToolHeader ${open2 ? "collapse" : "expand"}`}
                            onClick={() => setOpen2(!open2)}
                          >
                            <i className="fas fa-angle-up"></i>
                          </Link>
                        </div>
                      </div>
                      <Collapse in={open2}>
                        <div className="cm-content-body form excerpt">
                          <div className="card-body">
                            <div className="table-responsive">
                              <div id="content_wrapper" className="dataTables_wrapper no-footer">
                              <form onSubmit={handleSubmit}>
                <div className="row">
                  <div className="form-group mb-3 col-md-6">
                    <label>Store Name</label>
                    <input
                      type="text"
                      className="form-control"
                      name="name"
                      placeholder="Store Name"
                      value={formValues.name}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="form-group mb-3 col-md-6">
                    <label>Location</label>
                    <input
                      type="text"
                      className="form-control"
                      name="location"
                      placeholder="Location"
                      value={formValues.location}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                <button type="submit" className="btn btn-primary me-2 mt-3">
                  Add
                </button>
                <Link to="/store" className="btn btn-danger mt-3">
                  Cancel
                </Link>
              </form>
              <div className="d-sm-flex text-center justify-content-between align-items-center mt-3">
                                  
                                 
                                </div>
                                
                              </div>
                            </div>
                          </div>
                        </div>
                      </Collapse>
                    </div>
                  </div>
                </div>
    </>
  );
};

export default LoactionAdd;
